package com.epfafrica.etatcivil.infrastructure.persistence;

import com.epfafrica.etatcivil.domain.model.ActeDelivre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ActeDelivreRepository extends JpaRepository<ActeDelivre, Long> {
}